utils::globalVariables(c(
  "type", "yhat", "scb_low", "scb_up", "fct_reorder", "desc",
  "low", "up", "est_mean", "l_in", "l_est", "l_out", "true_mean", "l_true",
  "X1", "X2", "estimated_mean", "est", "SinCosSumNoise", "xlab", "ylab", "percent_change",
  "subject", "seconds", "Yhat", "id", ":=", "setNames", "resid", "time"
))
